from django.apps import AppConfig


class MathbotSiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mathbot_site'
