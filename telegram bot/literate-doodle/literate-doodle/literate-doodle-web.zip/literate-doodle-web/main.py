from aiogram import types
from aiogram.dispatcher import FSMContext
import math

@dp.message_handler(state=TrigonometryState.radian_into_degree)
async def trigonometry_radian_into_degree(message: types.Message, state: FSMContext):
    if message.text == 'Назад':
        await state.finish()
        await cmd_back(message)
    else:
        async with state.proxy() as data:
            data['radian_into_degree'] = message.text
            degree = (int(data["radian_into_degree"]) * 180 / math.pi) % 360
            answer_text = f'<b>Ответ: </b>{degree}\n'
            await bot.send_message(chat_id=message.from_user.id, text=answer_text, reply_markup=back_kb, parse_mode='HTML')
            await state.finish()